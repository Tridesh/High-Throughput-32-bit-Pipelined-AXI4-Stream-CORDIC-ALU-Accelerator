`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: tb_cordic_pipeline
// Description: Complete testbench to verify the 32-stage unrolled CORDIC pipeline
//              and its end-stage ALU functionality.
//////////////////////////////////////////////////////////////////////////////////

module tb_cordic_pipeline();

    // 1. Declare inputs to the Device Under Test (DUT) as registers
    reg         clk;
    reg         rst;
    reg  [2:0]  opcode_in;
    reg  signed [31:0] a_in;
    reg  signed [31:0] b_in;
    reg  signed [31:0] z_in;

    // Declare outputs from the DUT as wires
    wire [2:0]  opcode_out;
    wire signed [31:0] a_out;
    wire signed [31:0] b_out;
    wire signed [31:0] z_out;
    
    // New ALU Output Wires
    wire signed [31:0] add_out;
    wire signed [31:0] sub_out;
    wire signed [31:0] shift_a_out;
    wire signed [31:0] shift_b_out;
    wire signed [31:0] comp_a_out;
    wire signed [31:0] comp_b_out;

    // 2. Instantiate the Top-Level Pipeline Wrapper
    cordic_pipeline uut (
        .clk(clk),
        .rst(rst),
        .opcode_in(opcode_in),
        .a_in(a_in),
        .b_in(b_in),
        .z_in(z_in),
        .opcode_out(opcode_out),
        .a_out(a_out),
        .b_out(b_out),
        .z_out(z_out),
        // Connect the ALU outputs
        .add_out(add_out),
        .sub_out(sub_out),
        .shift_a_out(shift_a_out),
        .shift_b_out(shift_b_out),
        .comp_a_out(comp_a_out),
        .comp_b_out(comp_b_out)
    );

    // 3. Clock Generator: 100 MHz System Clock (10ns total period)
    always begin
        #5 clk = ~clk; // Changed from #2 to #5 to create a true 10ns period (100MHz)
    end

    // 4. Test Stimulus Control Loop
    integer i;
    initial begin
        // Initialize all inputs to a known safe state
        clk = 0;
        rst = 0; // Assert active-low reset to clear pipeline registers
        opcode_in = 3'b000;
        a_in = 32'h0;
        b_in = 32'h0;
        z_in = 32'h0;

        // Hold reset active for 20ns, then release it
        #20;
        rst = 1; 
        #10;

        // =================================================================
        // TEST CASE 1: Rotate Vector with 1/A Pre-scaling Optimization
        // Targets: 45 Degrees Rotation (Mode 1)
        // Fixed-point Mapping (Q2.30):
        // X = (1/A) * 2^30          = 32'h26DD3B66  (Pre-calculated 0.60725)
        // Y = 0.0                   = 32'h00000000
        // Z = 45 deg (0.7854 rad)  = 32'h3C518E64
        // =================================================================
        $display("[TB] Applying Input Stimulus: X=1/A, Y=0.0, Angle=45 degrees");
        
        a_in      = 32'h26DD3B66; // X initialized to 1/A to counteract gain
        b_in      = 32'h00000000; // Y initialized to 0.0
        z_in      = 32'h00000000; // Z = 45 degrees (~0.785398 rad in Q2.30)
        opcode_in = 3'd1;         // Set to rotation operation mode

        // Wait one clock edge to allow the pipeline to absorb this input vector
        @(posedge clk);
        #1;


        a_in      = 32'h26DD3B66; // X initialized to 1/A to counteract gain
        b_in      = 32'h00000000; // Y initialized to 0.0
        z_in      = 32'h3243F6A9; // Z = 45 degrees (~0.785398 rad in Q2.30)
        
        @(posedge clk);
        #1;
        // Clear inputs on the next cycle so we can see the data packet isolate inside the pipe
        a_in      = 32'h0;
        b_in      = 32'h0;
        z_in      = 32'h0;
        opcode_in = 3'd0;

        // 5. Wait exactly 31 clock cycles (since we already consumed 1 cycle above)
        // total 32 cycles for data to reach the output of the 32nd stage.
        $display("[TB] Data injected. Propagating through 32 pipeline stages...");
        for (i = 0; i < 31; i = i + 1) begin
            // We can actively monitor the 31st cycle specifically to check ALU changes if needed
            if (i == 30) begin
                $display("[TB] Packet has reached the 31st stage (Index 31). ALU math is computing...");
            end
            @(posedge clk);
        end
        
        // Allow an infinitesimal propagation delay for output wire stabilization
        #2; 

        // 6. Output Verification Display
        $display("==================================================");
        $display("[TB] SIMULATION OUTCOME REPORT");
        $display("==================================================");
        $display("--- CORDIC Core Vector Output ---");
        $display("Final Cosine Vector (a_out Hex): %h (Expected ~2D413CCD)", a_out);
        $display("Final Sine Vector   (b_out Hex): %h (Expected ~2D413CCD)", b_out);
        $display("Residual Target Reg (z_out Hex): %h (Expected near 00000000)", z_out);
        $display("Pipelined Opcode Out           : %d (Expected 1)", opcode_out);
        
        $display("\n--- End-Stage 31 ALU Outputs ---");
        $display("ALU Add Out         (add_out)    : %h", add_out);
        $display("ALU Sub Out         (sub_out)    : %h", sub_out);
        $display("ALU Shift A Out     (shift_a_out): %h", shift_a_out);
        $display("ALU Shift B Out     (shift_b_out): %h", shift_b_out);
        $display("ALU Comp A Out      (comp_a_out) : %h", comp_a_out);
        $display("ALU Comp B Out      (comp_b_out) : %h", comp_b_out);
        $display("==================================================");

        // Terminate testbench execution cleanly
        #50;
        $finish;
    end

endmodule